import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../routes/app_routes.dart';
import '../../services/app_data_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_navigation.dart';
import '../../widgets/empty_state_widget.dart';
import '../../widgets/loading_skeleton_widget.dart';
import './widgets/add_student_sheet_widget.dart';
import './widgets/student_card_widget.dart';

class StudentsScreen extends StatefulWidget {
  const StudentsScreen({super.key});

  @override
  State<StudentsScreen> createState() => _StudentsScreenState();
}

class _StudentsScreenState extends State<StudentsScreen>
    with TickerProviderStateMixin {
  int _navIndex = 1;
  bool _isLoading = true;
  String _searchQuery = '';
  String _selectedClass = 'All';
  bool _isSearching = false;

  final _searchController = TextEditingController();
  final _searchFocus = FocusNode();

  late AnimationController _listController;
  late List<Map<String, dynamic>> _students;

  List<String> get _classFilters {
    final classes = _students
        .map((s) => s['className'] as String)
        .toSet()
        .toList();
    classes.sort();
    return ['All', ...classes];
  }

  List<Map<String, dynamic>> get _filteredStudents {
    return _students.where((s) {
      final matchSearch =
          _searchQuery.isEmpty ||
          s['name'].toString().toLowerCase().contains(
            _searchQuery.toLowerCase(),
          ) ||
          s['rollNo'].toString().toLowerCase().contains(
            _searchQuery.toLowerCase(),
          );
      final matchClass =
          _selectedClass == 'All' || s['className'] == _selectedClass;
      return matchSearch && matchClass;
    }).toList();
  }

  @override
  void initState() {
    super.initState();
    _students = [];
    _listController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) {
      setState(() {
        _students = AppDataService.getStudents();
        _isLoading = false;
      });
      _listController.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _listController.dispose();
    _searchController.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  void _onNavTap(int index) {
    if (index == _navIndex) return;
    setState(() => _navIndex = index);
    if (index == 0) {
      Navigator.pushReplacementNamed(context, AppRoutes.dashboardScreen);
    } else if (index == 2) {
      Navigator.pushReplacementNamed(context, AppRoutes.reportsScreen);
    }
  }

  void _openAddStudent() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => AddStudentSheetWidget(
        onStudentAdded: (newStudent) async {
          await AppDataService.addStudent(newStudent);
          _loadData();
          if (ctx.mounted) Navigator.pop(ctx);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  '${newStudent['name']} added successfully!',
                  style: GoogleFonts.plusJakartaSans(),
                ),
                backgroundColor: AppTheme.success,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            );
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;
    final filtered = _filteredStudents;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: isTablet
            ? Row(
                children: [
                  AppNavigation(
                    currentIndex: _navIndex,
                    onDestinationSelected: _onNavTap,
                  ),
                  const VerticalDivider(width: 1),
                  Expanded(child: _buildBody(filtered, isTablet)),
                ],
              )
            : _buildBody(filtered, isTablet),
      ),
      bottomNavigationBar: isTablet
          ? null
          : AppNavigation(
              currentIndex: _navIndex,
              onDestinationSelected: _onNavTap,
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddStudent,
        icon: const Icon(Icons.person_add_rounded),
        label: Text(
          'Add Student',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildBody(List<Map<String, dynamic>> filtered, bool isTablet) {
    return Column(
      children: [
        _buildHeader(),
        _buildSearchBar(),
        _buildFilterChips(),
        _buildResultCount(filtered.length),
        Expanded(
          child: _isLoading
              ? const StudentListSkeletonWidget()
              : filtered.isEmpty
              ? EmptyStateWidget(
                  icon: Icons.person_search_rounded,
                  title: 'No students found',
                  subtitle: _searchQuery.isNotEmpty
                      ? 'Try a different name or roll number'
                      : 'Add your first student to get started',
                  actionLabel: _searchQuery.isEmpty ? 'Add Student' : null,
                  onAction: _searchQuery.isEmpty ? _openAddStudent : null,
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  color: AppTheme.primary,
                  child: isTablet
                      ? _buildTabletGrid(filtered)
                      : _buildPhoneList(filtered),
                ),
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      color: AppTheme.surface,
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.primaryContainer,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.people_rounded,
              color: AppTheme.primary,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Students',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                Text(
                  '${_students.length} students',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      color: AppTheme.surface,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: AppTheme.background,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _isSearching ? AppTheme.primary : AppTheme.outline,
            width: _isSearching ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            const SizedBox(width: 12),
            Icon(
              Icons.search_rounded,
              color: _isSearching ? AppTheme.primary : AppTheme.textSecondary,
              size: 20,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _searchController,
                focusNode: _searchFocus,
                onTap: () => setState(() => _isSearching = true),
                onChanged: (v) => setState(() => _searchQuery = v),
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  color: AppTheme.textPrimary,
                ),
                decoration: InputDecoration(
                  hintText: 'Search by name or roll number...',
                  hintStyle: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    color: AppTheme.textMuted,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                  filled: false,
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              GestureDetector(
                onTap: () {
                  _searchController.clear();
                  setState(() {
                    _searchQuery = '';
                    _isSearching = false;
                  });
                  _searchFocus.unfocus();
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Icon(
                    Icons.close_rounded,
                    color: AppTheme.textSecondary,
                    size: 18,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChips() {
    return Container(
      color: AppTheme.surface,
      child: Column(
        children: [
          SizedBox(
            height: 40,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
              itemCount: _classFilters.length,
              itemBuilder: (context, i) {
                final filter = _classFilters[i];
                final isSelected = _selectedClass == filter;
                return Padding(
                  padding: EdgeInsets.only(
                    right: i < _classFilters.length - 1 ? 8 : 0,
                  ),
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedClass = filter),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? AppTheme.primary
                            : AppTheme.surfaceVariant,
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Text(
                        filter,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: isSelected
                              ? Colors.white
                              : AppTheme.textSecondary,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          Container(height: 1, color: AppTheme.outlineVariant),
        ],
      ),
    );
  }

  Widget _buildResultCount(int count) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Row(
        children: [
          Text(
            '$count student${count != 1 ? 's' : ''}',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneList(List<Map<String, dynamic>> students) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
      itemCount: students.length,
      itemBuilder: (context, i) {
        final delay = Duration(milliseconds: (i * 50).clamp(0, 400));
        return FutureBuilder(
          future: Future.delayed(delay),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const SizedBox.shrink();
            }
            return TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutCubic,
              builder: (context, value, child) {
                return Transform.translate(
                  offset: Offset(0, 20 * (1 - value)),
                  child: Opacity(opacity: value, child: child),
                );
              },
              child: Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: StudentCardWidget(
                  student: students[i],
                  onTap: () => Navigator.pushNamed(
                    context,
                    AppRoutes.studentProfileScreen,
                    arguments: students[i],
                  ).then((_) => _loadData()),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTabletGrid(List<Map<String, dynamic>> students) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 2.2,
      ),
      itemCount: students.length,
      itemBuilder: (context, i) => StudentCardWidget(
        student: students[i],
        onTap: () => Navigator.pushNamed(
          context,
          AppRoutes.studentProfileScreen,
          arguments: students[i],
        ).then((_) => _loadData()),
      ),
    );
  }
}
