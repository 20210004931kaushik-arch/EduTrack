import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class AddStudentSheetWidget extends StatefulWidget {
  final Function(Map<String, dynamic>) onStudentAdded;

  const AddStudentSheetWidget({super.key, required this.onStudentAdded});

  @override
  State<AddStudentSheetWidget> createState() => _AddStudentSheetWidgetState();
}

class _AddStudentSheetWidgetState extends State<AddStudentSheetWidget>
    with SingleTickerProviderStateMixin {
  int _step = 0; // 0 = Basic Info, 1 = Fee Setup
  final _step1Key = GlobalKey<FormState>();
  final _step2Key = GlobalKey<FormState>();

  // Step 1 controllers
  final _nameController = TextEditingController();
  final _rollController = TextEditingController();
  final _classController = TextEditingController();
  final _phoneController = TextEditingController();
  DateTime? _admissionDate;

  // Step 2 controllers
  final _totalFeesController = TextEditingController();
  final _paidFeesController = TextEditingController();

  bool _isSaving = false;

  late AnimationController _stepController;
  late Animation<double> _stepFade;

  @override
  void initState() {
    super.initState();
    _stepController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..value = 1.0;
    _stepFade = CurvedAnimation(
      parent: _stepController,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _stepController.dispose();
    _nameController.dispose();
    _rollController.dispose();
    _classController.dispose();
    _phoneController.dispose();
    _totalFeesController.dispose();
    _paidFeesController.dispose();
    super.dispose();
  }

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: Theme.of(
            context,
          ).colorScheme.copyWith(primary: AppTheme.primary),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _admissionDate = picked);
    }
  }

  String _formatDate(DateTime date) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${date.day.toString().padLeft(2, '0')} ${months[date.month - 1]} ${date.year}';
  }

  void _goToStep2() {
    if (_step1Key.currentState!.validate()) {
      _stepController.reverse().then((_) {
        setState(() => _step = 1);
        _stepController.forward();
      });
    }
  }

  void _saveStudent() {
    if (_step2Key.currentState!.validate()) {
      setState(() => _isSaving = true);
      final total = int.tryParse(_totalFeesController.text) ?? 0;
      final paid = int.tryParse(_paidFeesController.text) ?? 0;
      final remaining = total - paid;
      String status;
      if (remaining <= 0) {
        status = 'Paid';
      } else if (paid == 0) {
        status = 'Overdue';
      } else {
        status = 'Due Soon';
      }
      final newStudent = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'name': _nameController.text.trim(),
        'rollNo': _rollController.text.trim(),
        'className': _classController.text.trim(),
        'subjects': '',
        'phone': '+91 ${_phoneController.text.trim()}',
        'admissionDate': _admissionDate != null
            ? _formatDate(_admissionDate!)
            : _formatDate(DateTime.now()),
        'totalFees': total,
        'paidFees': paid,
        'lastPayment': paid > 0 ? _formatDate(DateTime.now()) : 'Not paid',
        'nextDue': _formatDate(DateTime.now().add(const Duration(days: 30))),
        'status': status,
        'overduedays': status == 'Overdue' ? 0 : 0,
      };
      widget.onStudentAdded(newStudent);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 4),
              child: Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.outline,
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: AppTheme.primaryContainer,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.person_add_rounded,
                            color: AppTheme.primary,
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Add New Student',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                  color: AppTheme.textPrimary,
                                ),
                              ),
                              Text(
                                'Step ${_step + 1} of 2',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: const Icon(
                            Icons.close_rounded,
                            color: AppTheme.textSecondary,
                            size: 22,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    // Step indicator
                    _buildStepIndicator(),
                    const SizedBox(height: 20),
                    // Step content
                    FadeTransition(
                      opacity: _stepFade,
                      child: _step == 0 ? _buildStep1() : _buildStep2(),
                    ),
                    const SizedBox(height: 24),
                    // Action buttons
                    _buildActionButtons(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepIndicator() {
    return Row(
      children: [
        _StepCircle(
          number: 1,
          isActive: _step == 0,
          isDone: _step > 0,
          label: 'Basic Info',
        ),
        Expanded(
          child: Container(
            height: 2,
            color: _step > 0 ? AppTheme.primary : AppTheme.outline,
          ),
        ),
        _StepCircle(
          number: 2,
          isActive: _step == 1,
          isDone: false,
          label: 'Fee Setup',
        ),
      ],
    );
  }

  Widget _buildStep1() {
    return Form(
      key: _step1Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Student Information',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppTheme.primary,
            ),
          ),
          const SizedBox(height: 16),
          _buildField(
            controller: _nameController,
            label: 'Full Name *',
            icon: Icons.person_outline_rounded,
            validator: (v) =>
                v == null || v.trim().isEmpty ? 'Name is required' : null,
          ),
          const SizedBox(height: 12),
          _buildField(
            controller: _rollController,
            label: 'Roll Number *',
            icon: Icons.badge_outlined,
            validator: (v) => v == null || v.trim().isEmpty
                ? 'Roll number is required'
                : null,
          ),
          const SizedBox(height: 16),
          Text(
            'Class',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppTheme.primary,
            ),
          ),
          const SizedBox(height: 12),
          _buildField(
            controller: _classController,
            label: 'Class *',
            icon: Icons.menu_book_rounded,
            validator: (v) =>
                v == null || v.trim().isEmpty ? 'Class is required' : null,
          ),
          const SizedBox(height: 12),
          // Phone field
          TextFormField(
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            maxLength: 10,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              color: AppTheme.textPrimary,
            ),
            decoration: InputDecoration(
              labelText: 'Phone Number *',
              counterText: '',
              prefixIcon: Padding(
                padding: const EdgeInsets.only(left: 14, right: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.phone_outlined,
                      size: 18,
                      color: AppTheme.textSecondary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '+91',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Container(width: 1, height: 18, color: AppTheme.outline),
                  ],
                ),
              ),
              prefixIconConstraints: const BoxConstraints(minWidth: 0),
            ),
            validator: (v) {
              if (v == null || v.isEmpty) return 'Phone number is required';
              if (v.length != 10) return 'Enter exactly 10 digits';
              return null;
            },
          ),
          const SizedBox(height: 12),
          // Admission date
          GestureDetector(
            onTap: _selectDate,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.outline),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.calendar_today_outlined,
                    size: 18,
                    color: AppTheme.textSecondary,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _admissionDate != null
                          ? _formatDate(_admissionDate!)
                          : 'Admission Date',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        color: _admissionDate != null
                            ? AppTheme.textPrimary
                            : AppTheme.textMuted,
                      ),
                    ),
                  ),
                  const Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: AppTheme.textSecondary,
                    size: 20,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep2() {
    return Form(
      key: _step2Key,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Fee Configuration',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppTheme.primary,
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _totalFeesController,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: GoogleFonts.plusJakartaSans(
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              labelText: 'Total Annual Fees *',
              prefixIcon: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 14),
                child: Icon(
                  Icons.currency_rupee_rounded,
                  size: 18,
                  color: AppTheme.textSecondary,
                ),
              ),
              prefixIconConstraints: const BoxConstraints(minWidth: 0),
              helperText: 'Total fees for this academic year',
              hintText: 'e.g. 18000',
            ),
            validator: (v) {
              if (v == null || v.isEmpty) return 'Total fees is required';
              if (int.tryParse(v) == null) return 'Enter valid amount';
              return null;
            },
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _paidFeesController,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: GoogleFonts.plusJakartaSans(
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              labelText: 'Amount Already Paid',
              prefixIcon: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 14),
                child: Icon(
                  Icons.account_balance_wallet_outlined,
                  size: 18,
                  color: AppTheme.textSecondary,
                ),
              ),
              prefixIconConstraints: const BoxConstraints(minWidth: 0),
              helperText: 'Leave 0 if student has not paid yet',
            ),
            validator: (v) {
              if (v == null || v.isEmpty) return null;
              final paid = int.tryParse(v);
              final total = int.tryParse(_totalFeesController.text);
              if (paid == null) return 'Enter valid amount';
              if (total != null && paid > total) {
                return 'Paid cannot exceed total fees';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      style: GoogleFonts.plusJakartaSans(
        fontSize: 14,
        color: AppTheme.textPrimary,
      ),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Icon(icon, size: 18, color: AppTheme.textSecondary),
        ),
        prefixIconConstraints: const BoxConstraints(minWidth: 0),
      ),
      validator: validator,
    );
  }

  Widget _buildActionButtons() {
    if (_step == 0) {
      return SizedBox(
        width: double.infinity,
        height: 52,
        child: FilledButton.icon(
          onPressed: _goToStep2,
          icon: const Icon(Icons.arrow_forward_rounded),
          label: Text(
            'Continue to Fees',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    }
    return Row(
      children: [
        Expanded(
          flex: 2,
          child: SizedBox(
            height: 52,
            child: OutlinedButton(
              onPressed: () {
                _stepController.reverse().then((_) {
                  setState(() => _step = 0);
                  _stepController.forward();
                });
              },
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppTheme.primary),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                'Back',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.primary,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 3,
          child: SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _isSaving ? null : _saveStudent,
              icon: _isSaving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.check_rounded),
              label: Text(
                _isSaving ? 'Saving...' : 'Save Student',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _StepCircle extends StatelessWidget {
  final int number;
  final bool isActive;
  final bool isDone;
  final String label;

  const _StepCircle({
    required this.number,
    required this.isActive,
    required this.isDone,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: isActive || isDone ? AppTheme.primary : AppTheme.outline,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: isDone
                ? const Icon(Icons.check_rounded, color: Colors.white, size: 18)
                : Text(
                    '$number',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: isActive ? Colors.white : AppTheme.textMuted,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: isActive || isDone ? AppTheme.primary : AppTheme.textMuted,
          ),
        ),
      ],
    );
  }
}
