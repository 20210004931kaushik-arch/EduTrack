import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class KpiCardsWidget extends StatefulWidget {
  final Map<String, dynamic> stats;

  const KpiCardsWidget({super.key, required this.stats});

  @override
  State<KpiCardsWidget> createState() => _KpiCardsWidgetState();
}

class _KpiCardsWidgetState extends State<KpiCardsWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late List<Animation<Offset>> _slideAnimations;
  late List<Animation<double>> _fadeAnimations;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _slideAnimations = List.generate(
      4,
      (i) =>
          Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
            CurvedAnimation(
              parent: _controller,
              curve: Interval(
                i * 0.1,
                0.6 + i * 0.1,
                curve: Curves.easeOutCubic,
              ),
            ),
          ),
    );
    _fadeAnimations = List.generate(
      4,
      (i) => Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(i * 0.1, 0.6 + i * 0.1, curve: Curves.easeOut),
        ),
      ),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _formatCurrency(int amount) {
    if (amount >= 100000) {
      return '₹${(amount / 100000).toStringAsFixed(1)}L';
    } else if (amount >= 1000) {
      return '₹${(amount / 1000).toStringAsFixed(1)}K';
    }
    return '₹$amount';
  }

  @override
  Widget build(BuildContext context) {
    final cards = [
      _KpiData(
        label: 'Total Students',
        value: widget.stats['total'].toString(),
        icon: Icons.people_rounded,
        iconColor: AppTheme.primary,
        iconBg: AppTheme.primaryContainer,
        trend: null,
      ),
      _KpiData(
        label: 'Collected',
        value: _formatCurrency(widget.stats['collected'] as int),
        icon: Icons.account_balance_wallet_rounded,
        iconColor: AppTheme.success,
        iconBg: AppTheme.successContainer,
        trend: '+12%',
        trendUp: true,
      ),
      _KpiData(
        label: 'Pending',
        value: _formatCurrency(widget.stats['pending'] as int),
        icon: Icons.warning_amber_rounded,
        iconColor: AppTheme.warning,
        iconBg: AppTheme.warningContainer,
        trend: null,
        isAlert: true,
      ),
      _KpiData(
        label: 'Overdue',
        value: widget.stats['overdue'].toString(),
        icon: Icons.error_outline_rounded,
        iconColor: AppTheme.overdue,
        iconBg: AppTheme.errorContainer,
        trend: null,
        isAlert: widget.stats['overdue'] > 0,
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Overview',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.55,
          ),
          itemCount: 4,
          itemBuilder: (context, i) {
            return SlideTransition(
              position: _slideAnimations[i],
              child: FadeTransition(
                opacity: _fadeAnimations[i],
                child: _KpiCard(data: cards[i]),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _KpiData {
  final String label;
  final String value;
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String? trend;
  final bool? trendUp;
  final bool isAlert;

  const _KpiData({
    required this.label,
    required this.value,
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    this.trend,
    this.trendUp,
    this.isAlert = false,
  });
}

class _KpiCard extends StatelessWidget {
  final _KpiData data;

  const _KpiCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: data.isAlert
            ? Border.all(color: data.iconColor.withAlpha(77), width: 1.5)
            : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(13),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: data.iconBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(data.icon, color: data.iconColor, size: 18),
              ),
              if (data.trend != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: (data.trendUp == true)
                        ? AppTheme.successContainer
                        : AppTheme.errorContainer,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        data.trendUp == true
                            ? Icons.trending_up_rounded
                            : Icons.trending_down_rounded,
                        size: 11,
                        color: data.trendUp == true
                            ? AppTheme.success
                            : AppTheme.overdue,
                      ),
                      const SizedBox(width: 2),
                      Text(
                        data.trend!,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: data.trendUp == true
                              ? AppTheme.success
                              : AppTheme.overdue,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                data.value,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: data.isAlert ? data.iconColor : AppTheme.textPrimary,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
              const SizedBox(height: 2),
              Text(
                data.label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
