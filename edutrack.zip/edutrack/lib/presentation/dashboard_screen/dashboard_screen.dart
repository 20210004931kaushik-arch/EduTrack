import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../routes/app_routes.dart';
import '../../services/app_data_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_navigation.dart';
import '../../widgets/loading_skeleton_widget.dart';
import './widgets/dashboard_header_widget.dart';
import './widgets/kpi_cards_widget.dart';
import './widgets/overdue_slider_widget.dart';
import './widgets/quick_access_widget.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with TickerProviderStateMixin {
  int _navIndex = 0;
  bool _isLoading = true;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  late List<Map<String, dynamic>> _students;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOutCubic,
    );
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 700));
    if (mounted) {
      setState(() {
        _students = AppDataService.getStudents();
        _isLoading = false;
      });
      _fadeController.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  Map<String, dynamic> _getStats() {
    final total = _students.length;
    final paid = _students.where((s) => s['status'] == 'Paid').length;
    final overdue = _students.where((s) => s['status'] == 'Overdue').length;
    final totalCollected = _students.fold<int>(
      0,
      (sum, s) => sum + (s['paidFees'] as int),
    );
    final totalPending = _students.fold<int>(
      0,
      (sum, s) => sum + ((s['totalFees'] as int) - (s['paidFees'] as int)),
    );
    return {
      'total': total,
      'paid': paid,
      'overdue': overdue,
      'collected': totalCollected,
      'pending': totalPending,
    };
  }

  List<Map<String, dynamic>> get _overdueStudents =>
      _students.where((s) => s['status'] == 'Overdue').toList();

  void _onNavTap(int index) {
    if (index == _navIndex) return;
    setState(() => _navIndex = index);
    if (index == 1) {
      Navigator.pushNamed(context, AppRoutes.studentsScreen);
    } else if (index == 2) {
      Navigator.pushNamed(context, AppRoutes.reportsScreen);
    }
  }

  void _onQuickSearch(String rollNo) {
    final query = rollNo.trim().toLowerCase();
    final student = _students.firstWhere(
      (s) =>
          s['rollNo'].toString().toLowerCase() == query ||
          s['rollNo'].toString().toLowerCase().contains(query),
      orElse: () => {},
    );
    if (student.isNotEmpty) {
      Navigator.pushNamed(
        context,
        AppRoutes.studentProfileScreen,
        arguments: student,
      ).then((_) => _loadData());
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'No student found with roll number "$rollNo"',
            style: GoogleFonts.plusJakartaSans(),
          ),
          backgroundColor: AppTheme.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
    }
  }

  void _onPayStudent(Map<String, dynamic> student) {
    _showPaymentModal(student);
  }

  void _showPaymentModal(Map<String, dynamic> student) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PaymentBottomSheet(
        student: student,
        onPaymentDone: (amount) async {
          final idx = _students.indexWhere((s) => s['id'] == student['id']);
          if (idx != -1) {
            _students[idx]['paidFees'] =
                (_students[idx]['paidFees'] as int) + amount;
            final remaining =
                (_students[idx]['totalFees'] as int) -
                (_students[idx]['paidFees'] as int);
            _students[idx]['status'] = remaining <= 0 ? 'Paid' : 'Due Soon';
            _students[idx]['lastPayment'] = _formatDate(DateTime.now());
            _students[idx]['nextDue'] = _formatDate(
              DateTime.now().add(const Duration(days: 30)),
            );
            _students[idx]['overduedays'] = 0;
            // Add to payment history
            final history = List<Map<String, dynamic>>.from(
              (_students[idx]['paymentHistory'] as List?)
                      ?.cast<Map<String, dynamic>>() ??
                  [],
            );
            history.insert(0, {
              'date': _formatDate(DateTime.now()),
              'amount': amount,
              'method': 'Cash',
            });
            _students[idx]['paymentHistory'] = history;
            await AppDataService.updateStudent(_students[idx]);
          }
          setState(() {});
          Navigator.pop(ctx);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                '₹${_formatAmount(amount)} payment recorded for ${student['name']}',
                style: GoogleFonts.plusJakartaSans(),
              ),
              backgroundColor: AppTheme.success,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          );
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${date.day.toString().padLeft(2, '0')} ${months[date.month - 1]} ${date.year}';
  }

  String _formatAmount(int amount) {
    return amount.toString().replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (m) => '${m[1]},',
    );
  }

  @override
  Widget build(BuildContext context) {
    final stats = _isLoading ? <String, dynamic>{} : _getStats();
    final isTablet = MediaQuery.of(context).size.width >= 600;
    final institute = AppDataService.getInstitute();
    final instituteName = institute['name'] as String? ?? 'My Institute';

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: isTablet
            ? Row(
                children: [
                  AppNavigation(
                    currentIndex: _navIndex,
                    onDestinationSelected: _onNavTap,
                  ),
                  const VerticalDivider(width: 1),
                  Expanded(child: _buildBody(stats, isTablet, instituteName)),
                ],
              )
            : _buildBody(stats, isTablet, instituteName),
      ),
      bottomNavigationBar: isTablet
          ? null
          : AppNavigation(
              currentIndex: _navIndex,
              onDestinationSelected: _onNavTap,
            ),
    );
  }

  Widget _buildBody(
    Map<String, dynamic> stats,
    bool isTablet,
    String instituteName,
  ) {
    if (_isLoading) {
      return Column(
        children: [
          DashboardHeaderWidget(
            instituteName: instituteName,
            onSettingsTap: () => Navigator.pushNamed(
              context,
              AppRoutes.settingsScreen,
            ).then((_) => _loadData()),
          ),
          const Expanded(child: DashboardSkeletonWidget()),
        ],
      );
    }

    return FadeTransition(
      opacity: _fadeAnimation,
      child: RefreshIndicator(
        onRefresh: _loadData,
        color: AppTheme.primary,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: DashboardHeaderWidget(
                instituteName: instituteName,
                onSettingsTap: () => Navigator.pushNamed(
                  context,
                  AppRoutes.settingsScreen,
                ).then((_) => _loadData()),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: QuickAccessWidget(onSearch: _onQuickSearch),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: KpiCardsWidget(stats: stats),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
                child: OverdueSliderWidget(
                  overdueStudents: _overdueStudents,
                  onTapStudent: (s) => Navigator.pushNamed(
                    context,
                    AppRoutes.studentProfileScreen,
                    arguments: s,
                  ).then((_) => _loadData()),
                  onPayStudent: _onPayStudent,
                ),
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ),
      ),
    );
  }
}

// Payment bottom sheet
class _PaymentBottomSheet extends StatefulWidget {
  final Map<String, dynamic> student;
  final Function(int amount) onPaymentDone;

  const _PaymentBottomSheet({
    required this.student,
    required this.onPaymentDone,
  });

  @override
  State<_PaymentBottomSheet> createState() => _PaymentBottomSheetState();
}

class _PaymentBottomSheetState extends State<_PaymentBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  bool _isSubmitting = false;

  int get _remaining =>
      (widget.student['totalFees'] as int) -
      (widget.student['paidFees'] as int);

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.outline,
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.payment_rounded,
                      color: AppTheme.primary,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Record Payment',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      Text(
                        widget.student['name'],
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.warningContainer,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Remaining Balance',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13,
                        color: AppTheme.warning,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      '₹${_remaining.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.warning,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                autofocus: true,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                decoration: InputDecoration(
                  labelText: 'Payment Amount *',
                  prefixText: '₹ ',
                  prefixStyle: GoogleFonts.plusJakartaSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primary,
                  ),
                  helperText: 'Maximum: ₹$_remaining',
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Enter payment amount';
                  final amount = int.tryParse(v);
                  if (amount == null || amount <= 0) {
                    return 'Enter valid amount';
                  }
                  if (amount > _remaining) {
                    return 'Amount exceeds remaining balance';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton.icon(
                  onPressed: _isSubmitting
                      ? null
                      : () {
                          if (_formKey.currentState!.validate()) {
                            setState(() => _isSubmitting = true);
                            final amount = int.parse(_amountController.text);
                            widget.onPaymentDone(amount);
                          }
                        },
                  icon: _isSubmitting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.check_circle_rounded),
                  label: Text(
                    _isSubmitting ? 'Processing...' : 'Confirm Payment',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}
