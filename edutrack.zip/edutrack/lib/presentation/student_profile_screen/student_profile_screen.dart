import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../services/app_data_service.dart';
import '../../theme/app_theme.dart';
import './widgets/profile_action_buttons_widget.dart';
import './widgets/profile_basic_info_widget.dart';
import './widgets/profile_fee_summary_widget.dart';
import './widgets/profile_header_widget.dart';
import './widgets/profile_payment_history_widget.dart';

class StudentProfileScreen extends StatefulWidget {
  const StudentProfileScreen({super.key});

  @override
  State<StudentProfileScreen> createState() => _StudentProfileScreenState();
}

class _StudentProfileScreenState extends State<StudentProfileScreen>
    with TickerProviderStateMixin {
  late Map<String, dynamic> _student;
  bool _initialized = false;

  late AnimationController _entranceController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 450),
    );
    _fadeAnim = CurvedAnimation(
      parent: _entranceController,
      curve: Curves.easeOutCubic,
    );
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Curves.easeOutCubic,
          ),
        );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      final args = ModalRoute.of(context)?.settings.arguments;
      if (args != null && args is Map<String, dynamic>) {
        _student = Map<String, dynamic>.from(args);
      } else {
        _student = AppDataService.getStudents().isNotEmpty
            ? AppDataService.getStudents().first
            : {
                'id': '1',
                'name': 'Aryan Mehta',
                'rollNo': 'BFC-1042',
                'className': 'Class 12 Science',
                'subjects': 'Physics, Chemistry, Maths',
                'phone': '9876543210',
                'admissionDate': '05 Jun 2024',
                'totalFees': 48000,
                'paidFees': 24000,
                'lastPayment': '15 Mar 2025',
                'nextDue': '15 Apr 2025',
                'status': 'Overdue',
                'overduedays': 14,
                'paymentHistory': [],
              };
      }
      _initialized = true;
      _entranceController.forward();
    }
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  int get _remaining =>
      (_student['totalFees'] as int) - (_student['paidFees'] as int);

  void _showPaymentModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PaymentModal(
        student: _student,
        remaining: _remaining,
        onPaymentDone: (amount) async {
          setState(() {
            _student['paidFees'] = (_student['paidFees'] as int) + amount;
            final newRemaining =
                (_student['totalFees'] as int) - (_student['paidFees'] as int);
            _student['status'] = newRemaining <= 0 ? 'Paid' : 'Due Soon';
            _student['lastPayment'] = _formatDate(DateTime.now());
            _student['nextDue'] = _formatDate(
              DateTime.now().add(const Duration(days: 30)),
            );
            _student['overduedays'] = 0;
            final history = List<Map<String, dynamic>>.from(
              (_student['paymentHistory'] as List?)
                      ?.cast<Map<String, dynamic>>() ??
                  [],
            );
            history.insert(0, {
              'date': _formatDate(DateTime.now()),
              'amount': amount,
              'method': 'Cash',
            });
            _student['paymentHistory'] = history;
          });
          await AppDataService.updateStudent(_student);
          if (ctx.mounted) Navigator.pop(ctx);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  '₹${_formatCurrency(amount)} payment recorded successfully',
                  style: GoogleFonts.plusJakartaSans(),
                ),
                backgroundColor: AppTheme.success,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            );
          }
        },
      ),
    );
  }

  void _showWhatsApp() {
    final rawPhone = (_student['phone'] as String).replaceAll(
      RegExp(r'[^\d]'),
      '',
    );
    final phone = rawPhone.length == 10 ? '91$rawPhone' : rawPhone;
    final remaining = _remaining;
    final message =
        'Dear ${_student['name']},\n\nThis is a fee reminder.\n\n'
        '• Total Fees: ₹${_formatCurrency(_student['totalFees'] as int)}\n'
        '• Paid: ₹${_formatCurrency(_student['paidFees'] as int)}\n'
        '• Remaining: ₹${_formatCurrency(remaining)}\n'
        '• Next Due: ${_student['nextDue']}\n\n'
        'Please clear your dues at the earliest.\n\nThank you!';

    final encoded = Uri.encodeComponent(message);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'WhatsApp message ready for ${_student['name']}',
          style: GoogleFonts.plusJakartaSans(),
        ),
        backgroundColor: const Color(0xFF25D366),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        action: SnackBarAction(
          label: 'Open',
          textColor: Colors.white,
          onPressed: () {
            // URL: https://wa.me/$phone?text=$encoded
          },
        ),
      ),
    );
  }

  void _showEditModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _EditStudentModal(
        student: _student,
        onSaved: (updated) async {
          setState(() {
            _student = updated;
          });
          await AppDataService.updateStudent(updated);
          if (ctx.mounted) Navigator.pop(ctx);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Student details updated',
                  style: GoogleFonts.plusJakartaSans(),
                ),
                backgroundColor: AppTheme.primary,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            );
          }
        },
      ),
    );
  }

  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Move to Trash?',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Text(
          'This student will be moved to trash. You can restore them within 7 days from Settings.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 14,
            color: AppTheme.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'Cancel',
              style: GoogleFonts.plusJakartaSans(color: AppTheme.textSecondary),
            ),
          ),
          FilledButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await AppDataService.moveToTrash(_student['id'] as String);
              if (mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      '${_student['name']} moved to trash',
                      style: GoogleFonts.plusJakartaSans(),
                    ),
                    backgroundColor: AppTheme.error,
                    behavior: SnackBarBehavior.floating,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                );
              }
            },
            style: FilledButton.styleFrom(backgroundColor: AppTheme.error),
            child: Text(
              'Move to Trash',
              style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${date.day.toString().padLeft(2, '0')} ${months[date.month - 1]} ${date.year}';
  }

  String _formatCurrency(int amount) {
    return amount.toString().replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (m) => '${m[1]},',
    );
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: SlideTransition(
            position: _slideAnim,
            child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
          ),
        ),
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: ProfileHeaderWidget(
            student: _student,
            onBack: () => Navigator.pop(context),
            onDelete: _confirmDelete,
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: ProfileActionButtonsWidget(
              onPay: _showPaymentModal,
              onWhatsApp: _showWhatsApp,
              onEdit: _showEditModal,
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: ProfileBasicInfoWidget(student: _student),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: ProfileFeeSummaryWidget(student: _student),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            child: ProfilePaymentHistoryWidget(student: _student),
          ),
        ),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Column(
      children: [
        ProfileHeaderWidget(
          student: _student,
          onBack: () => Navigator.pop(context),
          onDelete: _confirmDelete,
        ),
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 5,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      ProfileActionButtonsWidget(
                        onPay: _showPaymentModal,
                        onWhatsApp: _showWhatsApp,
                        onEdit: _showEditModal,
                      ),
                      const SizedBox(height: 16),
                      ProfileBasicInfoWidget(student: _student),
                    ],
                  ),
                ),
              ),
              Expanded(
                flex: 5,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(0, 20, 20, 20),
                  child: Column(
                    children: [
                      ProfileFeeSummaryWidget(student: _student),
                      const SizedBox(height: 16),
                      ProfilePaymentHistoryWidget(student: _student),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Payment Modal ────────────────────────────────────────────────────────────
class _PaymentModal extends StatefulWidget {
  final Map<String, dynamic> student;
  final int remaining;
  final Function(int) onPaymentDone;

  const _PaymentModal({
    required this.student,
    required this.remaining,
    required this.onPaymentDone,
  });

  @override
  State<_PaymentModal> createState() => _PaymentModalState();
}

class _PaymentModalState extends State<_PaymentModal> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  bool _isSubmitting = false;

  String _formatCurrency(int amount) {
    return amount.toString().replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (m) => '${m[1]},',
    );
  }

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.outline,
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.payment_rounded,
                      color: AppTheme.primary,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Record Payment',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      Text(
                        widget.student['name'],
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.warningContainer,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Remaining Balance',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13,
                        color: AppTheme.warning,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      '₹${_formatCurrency(widget.remaining)}',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.warning,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                autofocus: true,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
                decoration: InputDecoration(
                  labelText: 'Payment Amount *',
                  prefixText: '₹ ',
                  prefixStyle: GoogleFonts.plusJakartaSans(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.primary,
                  ),
                  helperText:
                      'Maximum payable: ₹${_formatCurrency(widget.remaining)}',
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Enter payment amount';
                  final amount = int.tryParse(v);
                  if (amount == null || amount <= 0) {
                    return 'Enter a valid amount';
                  }
                  if (amount > widget.remaining) {
                    return 'Amount exceeds remaining balance';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton.icon(
                  onPressed: _isSubmitting
                      ? null
                      : () {
                          if (_formKey.currentState!.validate()) {
                            setState(() => _isSubmitting = true);
                            widget.onPaymentDone(
                              int.parse(_amountController.text),
                            );
                          }
                        },
                  icon: _isSubmitting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.check_circle_rounded),
                  label: Text(
                    _isSubmitting ? 'Processing...' : 'Confirm Payment',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Edit Student Modal ───────────────────────────────────────────────────────
class _EditStudentModal extends StatefulWidget {
  final Map<String, dynamic> student;
  final Function(Map<String, dynamic>) onSaved;

  const _EditStudentModal({required this.student, required this.onSaved});

  @override
  State<_EditStudentModal> createState() => _EditStudentModalState();
}

class _EditStudentModalState extends State<_EditStudentModal> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _classCtrl;
  late TextEditingController _subjectsCtrl;
  late TextEditingController _phoneCtrl;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(
      text: widget.student['name'] as String? ?? '',
    );
    _classCtrl = TextEditingController(
      text: widget.student['className'] as String? ?? '',
    );
    _subjectsCtrl = TextEditingController(
      text: widget.student['subjects'] as String? ?? '',
    );
    final rawPhone = (widget.student['phone'] as String? ?? '').replaceAll(
      RegExp(r'[^\d]'),
      '',
    );
    _phoneCtrl = TextEditingController(
      text: rawPhone.length > 10
          ? rawPhone.substring(rawPhone.length - 10)
          : rawPhone,
    );
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _classCtrl.dispose();
    _subjectsCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        decoration: const BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 4),
              child: Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.outline,
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: AppTheme.primaryContainer,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.edit_rounded,
                              color: AppTheme.primary,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Edit Student',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 17,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: const Icon(
                              Icons.close_rounded,
                              color: AppTheme.textSecondary,
                              size: 22,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      _buildField(
                        ctrl: _nameCtrl,
                        label: 'Full Name *',
                        icon: Icons.person_outline_rounded,
                        validator: (v) => v == null || v.trim().isEmpty
                            ? 'Name is required'
                            : null,
                      ),
                      const SizedBox(height: 12),
                      _buildField(
                        ctrl: _classCtrl,
                        label: 'Class *',
                        icon: Icons.menu_book_rounded,
                        validator: (v) => v == null || v.trim().isEmpty
                            ? 'Class is required'
                            : null,
                      ),
                      const SizedBox(height: 12),
                      _buildField(
                        ctrl: _subjectsCtrl,
                        label: 'Subjects',
                        icon: Icons.subject_rounded,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _phoneCtrl,
                        keyboardType: TextInputType.phone,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(10),
                        ],
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 14,
                          color: AppTheme.textPrimary,
                        ),
                        decoration: InputDecoration(
                          labelText: 'Phone (10 digits)',
                          prefixText: '+91 ',
                          prefixStyle: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            color: AppTheme.textSecondary,
                          ),
                          prefixIcon: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 14),
                            child: Icon(
                              Icons.phone_outlined,
                              size: 18,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                          prefixIconConstraints: const BoxConstraints(
                            minWidth: 0,
                          ),
                        ),
                        validator: (v) {
                          if (v != null && v.isNotEmpty && v.length != 10) {
                            return 'Phone must be 10 digits';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: FilledButton.icon(
                          onPressed: _isSaving
                              ? null
                              : () {
                                  if (_formKey.currentState!.validate()) {
                                    setState(() => _isSaving = true);
                                    final updated = Map<String, dynamic>.from(
                                      widget.student,
                                    );
                                    updated['name'] = _nameCtrl.text.trim();
                                    updated['className'] = _classCtrl.text
                                        .trim();
                                    updated['subjects'] = _subjectsCtrl.text
                                        .trim();
                                    updated['phone'] = _phoneCtrl.text.trim();
                                    widget.onSaved(updated);
                                  }
                                },
                          icon: _isSaving
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.save_rounded),
                          label: Text(
                            _isSaving ? 'Saving...' : 'Save Changes',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: ctrl,
      style: GoogleFonts.plusJakartaSans(
        fontSize: 14,
        color: AppTheme.textPrimary,
      ),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Icon(icon, size: 18, color: AppTheme.textSecondary),
        ),
        prefixIconConstraints: const BoxConstraints(minWidth: 0),
      ),
      validator: validator,
    );
  }
}
