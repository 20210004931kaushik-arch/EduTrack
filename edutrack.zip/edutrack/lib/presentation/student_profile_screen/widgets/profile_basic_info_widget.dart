import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class ProfileBasicInfoWidget extends StatelessWidget {
  final Map<String, dynamic> student;

  const ProfileBasicInfoWidget({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    final fields = [
      _InfoField('Full Name', student['name'] as String? ?? '-'),
      _InfoField('Roll Number', student['rollNo'] as String? ?? '-'),
      _InfoField('Class', student['className'] as String? ?? '-'),
      _InfoField(
        'Subjects',
        (student['subjects'] as String?)?.isNotEmpty == true
            ? student['subjects'] as String
            : 'Not specified',
      ),
      _InfoField('Phone', student['phone'] as String? ?? '-'),
      _InfoField('Admission Date', student['admissionDate'] as String? ?? '-'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(13),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
            child: Row(
              children: [
                const Icon(
                  Icons.person_outline_rounded,
                  color: AppTheme.primary,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Text(
                  'Basic Information',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.primary,
                  ),
                ),
              ],
            ),
          ),
          Container(height: 1, color: AppTheme.outlineVariant),
          ...fields.asMap().entries.map((entry) {
            final i = entry.key;
            final field = entry.value;
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 120,
                        child: Text(
                          field.label,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            color: AppTheme.textMuted,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          field.value,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (i < fields.length - 1)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    height: 1,
                    color: AppTheme.outlineVariant,
                  ),
              ],
            );
          }),
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

class _InfoField {
  final String label;
  final String value;
  const _InfoField(this.label, this.value);
}
