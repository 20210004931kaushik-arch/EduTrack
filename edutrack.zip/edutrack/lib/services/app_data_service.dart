import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class AppDataService {
  static const String _keyIsFirstTime = 'isFirstTimeUser';
  static const String _keyIsLoggedIn = 'isLoggedIn';
  static const String _keyStudents = 'students';
  static const String _keyTrash = 'trash';
  static const String _keyInstitute = 'institute';
  static const String _keyAdmin = 'admin';
  static const String _keyDarkMode = 'darkMode';

  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static SharedPreferences get prefs {
    if (_prefs == null) throw Exception('AppDataService not initialized');
    return _prefs!;
  }

  // ─── Auth ─────────────────────────────────────────────────────────────────
  static bool get isFirstTimeUser => prefs.getBool(_keyIsFirstTime) ?? true;
  static bool get isLoggedIn => prefs.getBool(_keyIsLoggedIn) ?? false;

  static Future<void> setFirstTimeUser(bool val) =>
      prefs.setBool(_keyIsFirstTime, val);
  static Future<void> setLoggedIn(bool val) =>
      prefs.setBool(_keyIsLoggedIn, val);

  // ─── Admin ────────────────────────────────────────────────────────────────
  static Map<String, dynamic> getAdmin() {
    final raw = prefs.getString(_keyAdmin);
    if (raw == null) return {};
    return Map<String, dynamic>.from(jsonDecode(raw));
  }

  static Future<void> saveAdmin(Map<String, dynamic> admin) =>
      prefs.setString(_keyAdmin, jsonEncode(admin));

  static bool validateLogin(String username, String password) {
    final admin = getAdmin();
    return admin['username'] == username && admin['password'] == password;
  }

  // ─── Institute ────────────────────────────────────────────────────────────
  static Map<String, dynamic> getInstitute() {
    final raw = prefs.getString(_keyInstitute);
    if (raw == null) {
      return {
        'name': 'My Institute',
        'type': 'Coaching',
        'studentRange': '1-50',
        'logo': null,
      };
    }
    return Map<String, dynamic>.from(jsonDecode(raw));
  }

  static Future<void> saveInstitute(Map<String, dynamic> institute) =>
      prefs.setString(_keyInstitute, jsonEncode(institute));

  // ─── Students ─────────────────────────────────────────────────────────────
  static List<Map<String, dynamic>> getStudents() {
    final raw = prefs.getString(_keyStudents);
    if (raw == null) return _defaultStudents();
    final list = jsonDecode(raw) as List;
    return list.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Future<void> saveStudents(List<Map<String, dynamic>> students) =>
      prefs.setString(_keyStudents, jsonEncode(students));

  static Future<void> addStudent(Map<String, dynamic> student) async {
    final students = getStudents();
    students.insert(0, student);
    await saveStudents(students);
  }

  static Future<void> updateStudent(Map<String, dynamic> updated) async {
    final students = getStudents();
    final idx = students.indexWhere((s) => s['id'] == updated['id']);
    if (idx != -1) students[idx] = updated;
    await saveStudents(students);
  }

  static Future<void> moveToTrash(String studentId) async {
    final students = getStudents();
    final idx = students.indexWhere((s) => s['id'] == studentId);
    if (idx == -1) return;
    final student = students.removeAt(idx);
    student['trashedAt'] = DateTime.now().toIso8601String();
    await saveStudents(students);
    final trash = getTrash();
    trash.insert(0, student);
    await saveTrash(trash);
  }

  // ─── Trash ────────────────────────────────────────────────────────────────
  static List<Map<String, dynamic>> getTrash() {
    final raw = prefs.getString(_keyTrash);
    if (raw == null) return [];
    final list = jsonDecode(raw) as List;
    return list.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Future<void> saveTrash(List<Map<String, dynamic>> trash) =>
      prefs.setString(_keyTrash, jsonEncode(trash));

  static Future<void> restoreFromTrash(String studentId) async {
    final trash = getTrash();
    final idx = trash.indexWhere((s) => s['id'] == studentId);
    if (idx == -1) return;
    final student = trash.removeAt(idx);
    student.remove('trashedAt');
    await saveTrash(trash);
    final students = getStudents();
    students.insert(0, student);
    await saveStudents(students);
  }

  static Future<void> permanentDelete(String studentId) async {
    final trash = getTrash();
    trash.removeWhere((s) => s['id'] == studentId);
    await saveTrash(trash);
  }

  static Future<void> autoDeleteOldTrash() async {
    final trash = getTrash();
    final now = DateTime.now();
    trash.removeWhere((s) {
      final trashedAt = s['trashedAt'] as String?;
      if (trashedAt == null) return false;
      final date = DateTime.tryParse(trashedAt);
      if (date == null) return false;
      return now.difference(date).inDays >= 7;
    });
    await saveTrash(trash);
  }

  // ─── Dark Mode ────────────────────────────────────────────────────────────
  static bool get isDarkMode => prefs.getBool(_keyDarkMode) ?? false;
  static Future<void> setDarkMode(bool val) => prefs.setBool(_keyDarkMode, val);

  // ─── Backup & Restore ─────────────────────────────────────────────────────
  static Map<String, dynamic> exportBackup() {
    return {
      'version': 1,
      'exportedAt': DateTime.now().toIso8601String(),
      'institute': getInstitute(),
      'students': getStudents(),
      'trash': getTrash(),
    };
  }

  static Future<void> importBackup(Map<String, dynamic> data) async {
    if (data['institute'] != null) {
      await saveInstitute(Map<String, dynamic>.from(data['institute']));
    }
    if (data['students'] != null) {
      final list = (data['students'] as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      await saveStudents(list);
    }
    if (data['trash'] != null) {
      final list = (data['trash'] as List)
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      await saveTrash(list);
    }
  }

  // ─── Logout ───────────────────────────────────────────────────────────────
  static Future<void> logout() async {
    await prefs.setBool(_keyIsLoggedIn, false);
  }

  // ─── Default Data ─────────────────────────────────────────────────────────
  static List<Map<String, dynamic>> _defaultStudents() {
    return [
      {
        'id': '1',
        'name': 'Aryan Mehta',
        'rollNo': 'BFC-1042',
        'className': 'Class 12 Science',
        'subjects': 'Physics, Chemistry, Maths',
        'phone': '9876543210',
        'admissionDate': '05 Jun 2024',
        'totalFees': 48000,
        'paidFees': 24000,
        'lastPayment': '15 Mar 2025',
        'nextDue': '15 Apr 2025',
        'status': 'Overdue',
        'overduedays': 14,
        'paymentHistory': [
          {'date': '15 Mar 2025', 'amount': 12000, 'method': 'Cash'},
          {'date': '15 Jan 2025', 'amount': 12000, 'method': 'Cash'},
        ],
      },
      {
        'id': '2',
        'name': 'Priya Sharma',
        'rollNo': 'BFC-1038',
        'className': 'Class 11 Science',
        'subjects': 'Physics, Chemistry, Biology',
        'phone': '9812345678',
        'admissionDate': '12 Jul 2024',
        'totalFees': 42000,
        'paidFees': 42000,
        'lastPayment': '10 Apr 2025',
        'nextDue': '10 May 2025',
        'status': 'Paid',
        'overduedays': 0,
        'paymentHistory': [
          {'date': '10 Apr 2025', 'amount': 14000, 'method': 'Online'},
          {'date': '10 Feb 2025', 'amount': 14000, 'method': 'Online'},
          {'date': '10 Dec 2024', 'amount': 14000, 'method': 'Online'},
        ],
      },
      {
        'id': '3',
        'name': 'Rohan Verma',
        'rollNo': 'BFC-1055',
        'className': 'Class 10',
        'subjects': 'Maths, Science, English',
        'phone': '9900112233',
        'admissionDate': '01 Apr 2024',
        'totalFees': 36000,
        'paidFees': 18000,
        'lastPayment': '05 Feb 2025',
        'nextDue': '05 Mar 2025',
        'status': 'Overdue',
        'overduedays': 55,
        'paymentHistory': [
          {'date': '05 Feb 2025', 'amount': 9000, 'method': 'Cash'},
          {'date': '05 Nov 2024', 'amount': 9000, 'method': 'Cash'},
        ],
      },
      {
        'id': '4',
        'name': 'Sneha Patil',
        'rollNo': 'BFC-1061',
        'className': 'Class 12 Commerce',
        'subjects': 'Accounts, Economics, Business',
        'phone': '9765432100',
        'admissionDate': '15 Jun 2024',
        'totalFees': 30000,
        'paidFees': 22500,
        'lastPayment': '20 Mar 2025',
        'nextDue': '20 Apr 2025',
        'status': 'Overdue',
        'overduedays': 9,
        'paymentHistory': [
          {'date': '20 Mar 2025', 'amount': 7500, 'method': 'Cash'},
          {'date': '20 Jan 2025', 'amount': 7500, 'method': 'Cash'},
          {'date': '20 Nov 2024', 'amount': 7500, 'method': 'Cash'},
        ],
      },
      {
        'id': '5',
        'name': 'Karan Singh',
        'rollNo': 'BFC-1047',
        'className': 'Class 9',
        'subjects': 'Maths, Science, SST',
        'phone': '9888776655',
        'admissionDate': '20 May 2024',
        'totalFees': 28000,
        'paidFees': 21000,
        'lastPayment': '25 Mar 2025',
        'nextDue': '25 Apr 2025',
        'status': 'Due Soon',
        'overduedays': 0,
        'paymentHistory': [
          {'date': '25 Mar 2025', 'amount': 7000, 'method': 'Online'},
          {'date': '25 Jan 2025', 'amount': 7000, 'method': 'Online'},
          {'date': '25 Nov 2024', 'amount': 7000, 'method': 'Cash'},
        ],
      },
      {
        'id': '6',
        'name': 'Ananya Joshi',
        'rollNo': 'BFC-1033',
        'className': 'Class 11 Commerce',
        'subjects': 'Accounts, Economics, Maths',
        'phone': '9654321098',
        'admissionDate': '10 Jun 2024',
        'totalFees': 32000,
        'paidFees': 32000,
        'lastPayment': '12 Apr 2025',
        'nextDue': '12 May 2025',
        'status': 'Paid',
        'overduedays': 0,
        'paymentHistory': [
          {'date': '12 Apr 2025', 'amount': 8000, 'method': 'Online'},
          {'date': '12 Feb 2025', 'amount': 8000, 'method': 'Online'},
          {'date': '12 Dec 2024', 'amount': 8000, 'method': 'Online'},
          {'date': '12 Oct 2024', 'amount': 8000, 'method': 'Online'},
        ],
      },
      {
        'id': '7',
        'name': 'Dev Kulkarni',
        'rollNo': 'BFC-1070',
        'className': 'Class 8',
        'subjects': 'Maths, Science',
        'phone': '9543210987',
        'admissionDate': '01 Jul 2024',
        'totalFees': 24000,
        'paidFees': 8000,
        'lastPayment': '10 Jan 2025',
        'nextDue': '10 Feb 2025',
        'status': 'Overdue',
        'overduedays': 79,
        'paymentHistory': [
          {'date': '10 Jan 2025', 'amount': 8000, 'method': 'Cash'},
        ],
      },
      {
        'id': '8',
        'name': 'Meera Nair',
        'rollNo': 'BFC-1029',
        'className': 'Class 12 Science',
        'subjects': 'Physics, Maths, Computer',
        'phone': '9432109876',
        'admissionDate': '05 Apr 2024',
        'totalFees': 48000,
        'paidFees': 36000,
        'lastPayment': '01 Apr 2025',
        'nextDue': '01 May 2025',
        'status': 'Due Soon',
        'overduedays': 0,
        'paymentHistory': [
          {'date': '01 Apr 2025', 'amount': 12000, 'method': 'Online'},
          {'date': '01 Feb 2025', 'amount': 12000, 'method': 'Online'},
          {'date': '01 Dec 2024', 'amount': 12000, 'method': 'Online'},
        ],
      },
      {
        'id': '9',
        'name': 'Rahul Gupta',
        'rollNo': 'BFC-1082',
        'className': 'Class 10',
        'subjects': 'Maths, Science, English',
        'phone': '9321098765',
        'admissionDate': '15 Mar 2025',
        'totalFees': 36000,
        'paidFees': 36000,
        'lastPayment': '15 Mar 2025',
        'nextDue': '15 Apr 2025',
        'status': 'Paid',
        'overduedays': 0,
        'paymentHistory': [
          {'date': '15 Mar 2025', 'amount': 36000, 'method': 'Online'},
        ],
      },
      {
        'id': '10',
        'name': 'Ishaan Reddy',
        'rollNo': 'BFC-1075',
        'className': 'Class 9',
        'subjects': 'Maths, Science, SST',
        'phone': '9210987654',
        'admissionDate': '10 Aug 2024',
        'totalFees': 28000,
        'paidFees': 14000,
        'lastPayment': '10 Mar 2025',
        'nextDue': '10 Apr 2025',
        'status': 'Overdue',
        'overduedays': 19,
        'paymentHistory': [
          {'date': '10 Mar 2025', 'amount': 7000, 'method': 'Cash'},
          {'date': '10 Jan 2025', 'amount': 7000, 'method': 'Cash'},
        ],
      },
      {
        'id': '11',
        'name': 'Tanya Bose',
        'rollNo': 'BFC-1066',
        'className': 'Class 11 Science',
        'subjects': 'Physics, Chemistry, Maths',
        'phone': '9109876543',
        'admissionDate': '20 Jun 2024',
        'totalFees': 42000,
        'paidFees': 42000,
        'lastPayment': '05 Apr 2025',
        'nextDue': '05 May 2025',
        'status': 'Paid',
        'overduedays': 0,
        'paymentHistory': [
          {'date': '05 Apr 2025', 'amount': 14000, 'method': 'Online'},
          {'date': '05 Feb 2025', 'amount': 14000, 'method': 'Online'},
          {'date': '05 Dec 2024', 'amount': 14000, 'method': 'Online'},
        ],
      },
      {
        'id': '12',
        'name': 'Siddharth Rao',
        'rollNo': 'BFC-1091',
        'className': 'Class 12 Commerce',
        'subjects': 'Accounts, Economics, Business',
        'phone': '9098765432',
        'admissionDate': '25 Feb 2025',
        'totalFees': 30000,
        'paidFees': 0,
        'lastPayment': 'Not paid',
        'nextDue': '25 Mar 2025',
        'status': 'Overdue',
        'overduedays': 35,
        'paymentHistory': [],
      },
    ];
  }
}
